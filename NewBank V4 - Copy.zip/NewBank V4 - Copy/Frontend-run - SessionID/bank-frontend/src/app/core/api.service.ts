import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';

const BASE_URL = 'http://localhost:5280/api';

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}

  // Register a new customer
  register(customer: any): Observable<any> {
    return this.http.post(`${BASE_URL}/customer/register`, customer);
  }

  // Login a customer and store token + customer info
  login(customerId: number, pin: string): Observable<any> {
    return this.http.post(`${BASE_URL}/customer/login`, {
      customerId,
      pin
    }).pipe(
      tap((response: any) => {
        if (response.token) {
          this.saveToken(response.token);
          localStorage.setItem('customer', JSON.stringify(response.customer));
        }
      })
    );
  }

  // Deposit an amount to a customer's account
  deposit(customerId: number, amount: number): Observable<any> {
    return this.http.post(`${BASE_URL}/transaction/deposit`, {
      customerId,
      amount
    });
  }

  // Withdraw an amount from a customer's account
  withdraw(customerId: number, amount: number): Observable<any> {
    return this.http.post(`${BASE_URL}/transaction/withdraw`, {
      customerId,
      amount
    });
  }

  // Get the balance of a customer's account
  getBalance(customerId: number): Observable<any> {
    return this.http.get(`${BASE_URL}/transaction/balance?customerId=${customerId}`);
  }

  // Forgot Customer ID - using email or phone
  forgotId(input: string): Observable<any> {
    return this.http.post(`${BASE_URL}/customer/forgot-id`, {
      input: input
    });
  }

  // Change customer PIN
  changePin(customerId: number, newPin: string): Observable<any> {
    return this.http.put(`${BASE_URL}/customer/change-pin`, {
      customerId,
      newPin
    });
  }

  // Delete a customer by customerId
  deleteCustomer(customerId: number): Observable<any> {
    return this.http.delete(`${BASE_URL}/customer/${customerId}`);
  }

  // Save token in localStorage
  saveToken(token: string): void {
    localStorage.setItem('token', token);
  }

  // Get token from localStorage
  getToken(): string | null {
    return localStorage.getItem('token');
  }

  // Logout and clear session data
  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('customer');
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  // Get logged-in customer info
  getLoggedInCustomer(): any {
    const customer = localStorage.getItem('customer');
    return customer ? JSON.parse(customer) : null;
  }
}

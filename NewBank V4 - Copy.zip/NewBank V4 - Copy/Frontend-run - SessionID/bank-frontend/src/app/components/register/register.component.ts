import { Component } from '@angular/core';
import { ApiService } from '../../core/api.service';

@Component({
  selector: 'app-register',
  template: `
    <div class="register-wrapper">
      <div class="register-box">
        <h2>Create Your Account</h2>
        <form (submit)="register()">
          <input [(ngModel)]="model.name" name="name" placeholder="Full Name" required />
          <input [(ngModel)]="model.email" name="email" type="email" placeholder="Email" />
          <input [(ngModel)]="model.phone" name="phone" placeholder="Phone Number" />
          <input [(ngModel)]="model.pin" name="pin" type="password" placeholder="Set PIN" required />
          <button type="submit">Register</button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .register-wrapper {
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: linear-gradient(to right, #f5f7fa, #c3cfe2);
      font-family: 'Segoe UI', sans-serif;
    }

    .register-box {
      background-color: #ffffff;
      padding: 40px 30px;
      border-radius: 12px;
      box-shadow: 0px 15px 25px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 450px;
      transition: all 0.3s ease-in-out;
    }

    .register-box h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #002244;
    }

    .register-box input {
      width: 100%;
      padding: 12px;
      margin-bottom: 16px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 15px;
      transition: border 0.3s ease;
    }

    .register-box input:focus {
      outline: none;
      border: 1px solid #0066cc;
      box-shadow: 0 0 5px rgba(0, 102, 204, 0.3);
    }

    .register-box button {
      width: 100%;
      padding: 12px;
      background-color: #004080;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s ease-in-out;
    }

    .register-box button:hover {
      background-color: #002244;
    }
  `]
})
export class RegisterComponent {
  model: any = {};

  constructor(private api: ApiService) {}

  register() {
    this.api.register(this.model).subscribe(() => alert('Registered successfully!'));
  }
}

import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  template: `
    <div class="dashboard-container">
      <div class="dashboard-card">
        <h2>Welcome, Customer #{{ customerId }}</h2>

        <div class="section">
          <button class="primary-btn" (click)="checkBalance()">Check Balance</button>
          <p *ngIf="balance !== undefined" class="balance-text">💰 Balance: ₹{{ balance }}</p>
        </div>

        <div class="section">
          <input [(ngModel)]="amount" type="number" placeholder="Enter Amount" />
          <div class="action-buttons">
            <button class="deposit-btn" (click)="deposit()">Deposit</button>
            <button class="withdraw-btn" (click)="withdraw()">Withdraw</button>
          </div>
        </div>

        <div class="section">
          <button class="delete-btn" (click)="deleteAccount()">Delete Account</button>
        </div>

        <div class="logout-wrapper">
          <button class="logout-btn" (click)="logout()">Logout</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: linear-gradient(to right, #f0f4f8, #d9e2ec);
      font-family: 'Segoe UI', sans-serif;
    }

    .dashboard-card {
      background-color: #ffffff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 500px;
      text-align: center;
    }

    .dashboard-card h2 {
      margin-bottom: 20px;
      color: #003366;
    }

    .section {
      margin-top: 30px;
    }

    input[type="number"],
    input[type="text"],
    input[type="email"],
    input[type="password"] {
      padding: 12px;
      width: 100%;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }

    .primary-btn {
      padding: 12px 20px;
      background-color: #004080;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      margin-bottom: 10px;
      width: 100%;
    }

    .balance-text {
      font-size: 18px;
      color: #006600;
      margin-top: 10px;
    }

    .action-buttons {
      display: flex;
      justify-content: space-between;
      gap: 10px;
    }

    .deposit-btn, .withdraw-btn {
      flex: 1;
      padding: 12px;
      font-weight: bold;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .deposit-btn {
      background-color: rgb(61, 40, 167);
      color: white;
    }

    .withdraw-btn {
      background-color: rgb(67, 68, 70);
      color: white;
    }

    .deposit-btn:hover {
      background-color: #218838;
    }

    .withdraw-btn:hover {
      background-color: #c82333;
    }

    .logout-wrapper {
      margin-top: 20px;
    }

    .logout-btn {
      padding: 12px 20px;
      background-color: rgb(63, 117, 199);
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      width: 100%;
    }

    .logout-btn:hover {
      background-color: #e53e3e;
    }

    .delete-btn {
      background-color: #b20000;
      padding: 12px;
      font-weight: bold;
      border: none;
      border-radius: 6px;
      color: white;
      cursor: pointer;
      width: 100%;
    }

    .delete-btn:hover {
      background-color: #990000;
    }
  `]
})
export class DashboardComponent implements OnInit {
  customerId!: number;
  amount!: number;
  balance?: number;

  constructor(private api: ApiService, private router: Router) {}

  ngOnInit() {
    const user = localStorage.getItem('customer');
    if (user) {
      const customer = JSON.parse(user);
      this.customerId = customer.id;
    } else {
      this.router.navigate(['/login']);
    }
  }

  checkBalance() {
    this.api.getBalance(this.customerId).subscribe({
      next: (res) => (this.balance = res.balance),
      error: () => {
        this.balance = undefined;
        console.error('Failed to fetch balance.');
      }
    });
  }

  deposit() {
    this.api.deposit(this.customerId, this.amount).subscribe({
      next: () => this.checkBalance(),
      error: () => console.error('Deposit failed.')
    });
  }

  withdraw() {
    this.api.withdraw(this.customerId, this.amount).subscribe({
      next: () => this.checkBalance(),
      error: () => console.error('Withdrawal failed.')
    });
  }

  deleteAccount() {
    if (confirm('Are you sure you want to delete your account?')) {
      this.api.deleteCustomer(this.customerId).subscribe({
        next: () => {
          alert('Account deleted.');
          this.logout();
        },
        error: () => alert('Failed to delete account')
      });
    }
  }

  logout() {
    localStorage.removeItem('customer');
    this.router.navigate(['/login']);
  }
}

import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { ApiService } from '../core/api.service';
import * as CustomerActions from './customer.actions';
import { catchError, map, mergeMap, of } from 'rxjs';

@Injectable()
export class CustomerEffects {
  constructor(private actions$: Actions, private api: ApiService) {}

  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CustomerActions.loginCustomer),
      mergeMap(({ id, pin }) =>
        this.api.login(id, pin).pipe(
          map(() => CustomerActions.loginSuccess({ id })),
          catchError(() => of(CustomerActions.logout()))
        )
      )
    )
  );
}

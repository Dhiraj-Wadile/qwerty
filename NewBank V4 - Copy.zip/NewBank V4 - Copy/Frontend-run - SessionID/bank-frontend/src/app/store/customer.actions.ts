import { createAction, props } from '@ngrx/store';

export const loginCustomer = createAction(
  '[Customer] Login',
  props<{ id: number; pin: string }>()
);

export const loginSuccess = createAction(
  '[Customer] Login Success',
  props<{ id: number }>()
);

export const logout = createAction('[Customer] Logout');

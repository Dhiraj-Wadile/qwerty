﻿namespace BankingBackend.Models
{
    public class LoginRequest
    {
        public int CustomerId { get; set; }
        public string Pin { get; set; }
    }
}

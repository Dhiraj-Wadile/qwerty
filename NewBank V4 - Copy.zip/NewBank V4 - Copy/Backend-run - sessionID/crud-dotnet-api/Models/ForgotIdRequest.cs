﻿namespace BankingBackend.Models
{
    public class ForgotIdRequest
    {
        public string Input { get; set; } = string.Empty;
    }
}

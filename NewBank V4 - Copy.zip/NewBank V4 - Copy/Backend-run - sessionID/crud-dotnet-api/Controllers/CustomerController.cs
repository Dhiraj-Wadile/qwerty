﻿using BankingBackend.Models;
using BankingBackend.Repositories;
using BankingBackend.Services;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class CustomerController : ControllerBase
{
    private readonly CustomerRepository _repository;
    private readonly AuthService _authService;

    public CustomerController(CustomerRepository repository, AuthService authService)
    {
        _repository = repository;
        _authService = authService;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var customer = await _repository.LoginAsync(request.CustomerId, request.Pin);
        if (customer == null)
            return Unauthorized("Invalid credentials");

        var token = _authService.GenerateJwtToken(customer.Name);
        return Ok(new { token, customer });
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] Customer customer)
    {
        if (customer == null || string.IsNullOrWhiteSpace(customer.Name))
            return BadRequest("Invalid customer data.");

        await _repository.AddAsync(customer);
        return Ok(new { message = "Registration successful" });
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var customers = await _repository.GetAllAsync();
        return Ok(customers);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var customer = await _repository.GetByIdAsync(id);
        if (customer == null)
            return NotFound();

        return Ok(customer);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var customer = await _repository.GetByIdAsync(id);
        if (customer == null)
            return NotFound();

        await _repository.DeleteAsync(id);
        return Ok(new { message = "Customer deleted successfully" });
    }

    [HttpPost("forgot-id")]
    public async Task<IActionResult> ForgotCustomerId([FromBody] ForgotIdRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Input))
            return BadRequest("Input is required");

        var customer = await _repository.GetByEmailOrPhoneAsync(request.Input);
        if (customer == null)
            return NotFound("Customer not found with provided email or phone.");

        return Ok(new { customerId = customer.Id, name = customer.Name });
    }
}

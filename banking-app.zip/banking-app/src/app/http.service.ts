import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './interfaces/customer';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  private apiUrl = 'http://localhost:5280/api/Customer';

  constructor(private http: HttpClient) {}

  getCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.apiUrl);
  }

  addCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.apiUrl, customer);
  }

  checkBalance(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/balance/${id}`);
  }

  withdrawAmount(id: number, amount: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/withdraw/${id}/${amount}`, {});
  }
}

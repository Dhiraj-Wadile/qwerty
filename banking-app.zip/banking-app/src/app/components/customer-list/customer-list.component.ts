import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../http.service';
import { Customer } from '../../interfaces/customer';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  customers: Customer[] = [];

  constructor(private httpService: HttpService) {}

  ngOnInit() {
    this.httpService.getCustomers().subscribe(data => {
      this.customers = data;
    });
  }
}

import { Component } from '@angular/core';
import { HttpService } from '../../http.service';
import { Customer } from '../../interfaces/customer';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css']
})
export class CustomerFormComponent {
  customer: Customer = { name: '', email: '', phone: '' };
  private readonly pin: string = '0000'; // Fixed PIN
  balance: number = 1000; // Fixed balance
  enteredPin: string = ''; // Stores entered PIN
  withdrawAmount: number = 0; // Stores withdrawal amount
  balanceMessage: string = ''; // Stores messages for balance/withdrawal

  constructor(private httpService: HttpService) {}

  addCustomer() {
    this.httpService.addCustomer(this.customer).subscribe(response => {
      console.log('Customer Added:', response);
      this.customer = { name: '', email: '', phone: '' };
    });
  }

  checkBalance() {
    if (this.enteredPin === this.pin) {
      this.balanceMessage = `Your balance is ₹${this.balance}`;
      console.log(this.balanceMessage);
    } else {
      this.balanceMessage = 'Incorrect PIN! Balance check failed.';
      console.log(this.balanceMessage);
    }
  }

  withdraw() {
    if (this.enteredPin === this.pin) {
      if (this.withdrawAmount > 0) {
        if (this.withdrawAmount <= this.balance) {
          this.balance -= this.withdrawAmount;
          this.balanceMessage = `₹${this.withdrawAmount} withdrawn. Remaining balance: ₹${this.balance}`;
          console.log(this.balanceMessage);
        } else {
          this.balanceMessage = 'Insufficient balance!';
          console.log(this.balanceMessage);
        }
      } else {
        this.balanceMessage = 'Invalid withdrawal amount!';
        console.log(this.balanceMessage);
      }
    } else {
      this.balanceMessage = 'Incorrect PIN! Withdrawal failed.';
      console.log(this.balanceMessage);
    }
  }
}

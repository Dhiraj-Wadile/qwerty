import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { CustomerFormComponent } from './components/customer-form/customer-form.component';
import { CustomerListComponent } from './components/customer-list/customer-list.component';
import { AppRoutingModule } from './app-routing.module'; // Import Routing Module
import { HttpService } from './http.service';

@NgModule({
  declarations: [
    AppComponent,
    CustomerFormComponent,
    CustomerListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule // Use the Routing Module
  ],
  providers: [HttpService],
  bootstrap: [AppComponent]
})
export class AppModule { }

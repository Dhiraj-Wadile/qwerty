// File Path: C:\Users\dmwad\OneDrive\Desktop\newqwerty\banking-app\src\app\interfaces\customer.ts

export interface Customer {
    id?: number;
    name: string;
    email: string;
    phone: string;
  }
  
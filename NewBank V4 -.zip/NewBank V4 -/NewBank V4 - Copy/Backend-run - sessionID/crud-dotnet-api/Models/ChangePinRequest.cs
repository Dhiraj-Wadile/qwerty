﻿namespace BankingBackend.Models
{
    public class ChangePinRequest
    {
        public string NewPin { get; set; } = string.Empty;
    }
}

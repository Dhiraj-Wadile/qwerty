﻿using BankingBackend.Models;
using BankingBackend.Services;
using Dapper;
using System.Data;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace BankingBackend.Repositories
{
    public class CustomerRepository
    {
        private readonly DatabaseService _dbService;

        public CustomerRepository(DatabaseService dbService)
        {
            _dbService = dbService;
        }

        public async Task<List<Customer>> GetAllAsync()
        {
            const string query = "SELECT * FROM Customers";
            using IDbConnection connection = _dbService.CreateConnection();
            var result = await connection.QueryAsync<Customer>(query);
            return result.ToList();
        }

        public async Task<Customer?> GetByIdAsync(int id)
        {
            const string query = "SELECT * FROM Customers WHERE Id = @Id";
            using IDbConnection connection = _dbService.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<Customer>(query, new { Id = id });
        }

        public async Task AddAsync(Customer customer)
        {
            const string query = @"
                INSERT INTO Customers (Name, Email, Phone, Pin, Balance) 
                VALUES (@Name, @Email, @Phone, @Pin, @Balance)";
            using IDbConnection connection = _dbService.CreateConnection();
            await connection.ExecuteAsync(query, customer);
        }

        public async Task<Customer?> LoginAsync(int customerId, string pin)
        {
            const string query = "SELECT * FROM Customers WHERE Id = @Id AND Pin = @Pin";
            using IDbConnection connection = _dbService.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<Customer>(query, new { Id = customerId, Pin = pin });
        }


        //public async Task<Customer?> LoginAsync(int customerId, string pin)
        //{
        //    const string query = "SELECT * FROM Customers WHERE Id = @Id AND Pin = @Pin";
        //    using IDbConnection connection = _dbService.CreateConnection();
        //    return await connection.QueryFirstOrDefaultAsync<Customer>(query, new { Id = customerId, Pin = pin });
        //}

        public async Task<Customer?> GetByEmailOrPhoneAsync(string input)
        {
            const string query = @"
                SELECT * FROM Customers 
                WHERE Email = @Input OR Phone = @Input";

            using IDbConnection connection = _dbService.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<Customer>(query, new { Input = input });
        }

        public async Task UpdateAsync(Customer customer)
        {
            const string query = @"
                UPDATE Customers 
                SET Name = @Name, Email = @Email, Phone = @Phone, Pin = @Pin 
                WHERE Id = @Id";
            using IDbConnection connection = _dbService.CreateConnection();
            await connection.ExecuteAsync(query, customer);
        }

        public async Task DeleteAsync(int id)
        {
            const string query = "DELETE FROM Customers WHERE Id = @Id";
            using IDbConnection connection = _dbService.CreateConnection();
            await connection.ExecuteAsync(query, new { Id = id });
        }
    }
}

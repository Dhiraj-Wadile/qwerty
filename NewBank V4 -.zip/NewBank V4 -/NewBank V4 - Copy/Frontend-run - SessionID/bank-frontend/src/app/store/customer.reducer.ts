import { createReducer, on } from '@ngrx/store';
import * as CustomerActions from './customer.actions';

export interface CustomerState {
  id: number | null;
  isLoggedIn: boolean;
}

const initialState: CustomerState = {
  id: null,
  isLoggedIn: false
};

export const customerReducer = createReducer(
  initialState,
  on(CustomerActions.loginSuccess, (state, { id }) => ({
    ...state,
    id,
    isLoggedIn: true
  })),
  on(CustomerActions.logout, () => initialState)
);

// Selector to check login status
export const selectIsLoggedIn = (state: CustomerState) => state.isLoggedIn;

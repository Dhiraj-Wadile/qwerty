import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import * as CustomerActions from '../../store/customer.actions';
import { ApiService } from '../../core/api.service';

@Component({
  selector: 'app-login',
  template: `
    <div class="login-wrapper">
      <div class="login-box">
        <h2>Bank Login</h2>
        <form (submit)="login($event)">
          <input [(ngModel)]="id" name="id" placeholder="Customer ID" required />
          <input [(ngModel)]="pin" name="pin" type="password" placeholder="PIN" required />
          <button type="submit">Login</button>
        </form>

        <!-- ✅ Forgot ID button -->
        <button style="margin-top: 15px; background-color: #888; font-size: 14px;" (click)="fetchCustomerIds()">
          Forgot ID?
        </button>

        <!-- ✅ Customer list display -->
        <div *ngIf="customers.length > 0" style="margin-top: 20px;">
          <h4>Registered Customers</h4>
          <ul>
            <li *ngFor="let customer of customers">
              <strong>ID:</strong> {{ customer.id }} |
              <strong>Name:</strong> {{ customer.name }} |
              <strong>Email:</strong> {{ customer.email }} |
              <strong>Phone:</strong> {{ customer.phone }}
            </li>
          </ul>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-wrapper {
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: linear-gradient(to right, #e0eafc, #cfdef3);
      font-family: 'Segoe UI', sans-serif;
    }

    .login-box {
      background-color: #ffffff;
      padding: 40px 30px;
      border-radius: 12px;
      box-shadow: 0px 15px 25px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
      transition: all 0.3s ease-in-out;
    }

    .login-box h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #002244;
    }

    .login-box input {
      width: 100%;
      padding: 12px;
      margin-bottom: 18px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 15px;
      transition: border 0.3s ease;
    }

    .login-box input:focus {
      outline: none;
      border: 1px solid #004080;
      box-shadow: 0 0 5px rgba(0, 64, 128, 0.3);
    }

    .login-box button {
      width: 100%;
      padding: 12px;
      background-color: #004080;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s ease-in-out;
    }

    .login-box button:hover {
      background-color: #002244;
    }

    ul {
      list-style-type: none;
      padding: 0;
    }

    ul li {
      margin: 5px 0;
      font-size: 14px;
      background: #f3f3f3;
      padding: 8px;
      border-radius: 4px;
    }
  `]
})
export class LoginComponent {
  id!: number;
  pin!: string;
  customers: any[] = [];

  constructor(
    private store: Store,
    private api: ApiService,
    private router: Router
  ) {}

  login(event: Event) {
    event.preventDefault();
    this.store.dispatch(CustomerActions.loginCustomer({ id: this.id, pin: this.pin }));
    alert("✅ Login successful!\n\nYou can now check your balance, deposit, or withdraw money from the dashboard.");
    this.router.navigate(['/dashboard']);
  }

  fetchCustomerIds() {
    this.api.getAllCustomerIds().subscribe({
      next: (data) => {
        this.customers = data;
      },
      error: (err) => {
        alert("Failed to load customer list.");
        console.error(err);
      }
    });
  }
}

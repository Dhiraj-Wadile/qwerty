import { Component } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-dashboard',
  template: `
    <div class="dashboard-container">
      <div class="dashboard-card">
        <h2>Welcome, Customer #{{ customerId }}</h2>

        <div class="section">
          <button class="primary-btn" (click)="checkBalance()">Check Balance</button>
          <p *ngIf="balance !== undefined" class="balance-text">💰 Balance: ₹{{ balance }}</p>
        </div>

        <div class="section">
          <input [(ngModel)]="amount" type="number" placeholder="Enter Amount" />
          <div class="action-buttons">
            <button class="deposit-btn" (click)="deposit()">Deposit</button>
            <button class="withdraw-btn" (click)="withdraw()">Withdraw</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: linear-gradient(to right, #f0f4f8, #d9e2ec);
      font-family: 'Segoe UI', sans-serif;
    }

    .dashboard-card {
      background-color: #ffffff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 500px;
      text-align: center;
    }

    .dashboard-card h2 {
      margin-bottom: 20px;
      color: #003366;
    }

    .section {
      margin-top: 30px;
    }

    input[type="number"] {
      padding: 12px;
      width: 100%;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
      transition: border 0.3s ease;
    }

    input[type="number"]:focus {
      outline: none;
      border-color: #0055cc;
      box-shadow: 0 0 5px rgba(0, 85, 204, 0.2);
    }

    .primary-btn {
      padding: 10px 20px;
      background-color: #004080;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      margin-bottom: 10px;
    }

    .balance-text {
      font-size: 18px;
      color: #006600;
      margin-top: 10px;
    }

    .action-buttons {
      display: flex;
      justify-content: space-between;
      gap: 10px;
    }

    .deposit-btn, .withdraw-btn {
      flex: 1;
      padding: 10px;
      font-weight: bold;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.3s ease;
    }

    .deposit-btn {
      background-color: #28a745;
      color: white;
    }

    .withdraw-btn {
      background-color: #dc3545;
      color: white;
    }

    .deposit-btn:hover {
      background-color: #218838;
    }

    .withdraw-btn:hover {
      background-color: #c82333;
    }
  `]
})
export class DashboardComponent {
  customerId!: number;
  amount!: number;
  balance?: number;

  constructor(private api: ApiService, private store: Store<{ customer: any }>) {
    this.store.select('customer').subscribe((c) => {
      this.customerId = c.id;
    });
  }

  checkBalance() {
    this.api.getBalance(this.customerId).subscribe({
      next: (res) => this.balance = res.balance,
      error: () => alert('Failed to fetch balance.')
    });
  }

  deposit() {
    this.api.deposit(this.customerId, this.amount).subscribe({
      next: () => {
        alert('✅ Deposit successful');
        this.checkBalance(); // Update balance after deposit
      },
      error: () => alert('Deposit failed. Please try again.')
    });
  }

  withdraw() {
    this.api.withdraw(this.customerId, this.amount).subscribe({
      next: () => {
        alert('✅ Withdrawal successful');
        this.checkBalance(); // Update balance after withdraw
      },
      error: (err) => {
        const errorMessage = err.error || 'Withdrawal failed. Please try again.';
        alert(`⚠️ ${errorMessage}`);
      }
    });
  }
}


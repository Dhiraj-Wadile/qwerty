import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const BASE_URL = 'http://localhost:5280/api';

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}

  // ✅ Register customer using POST /customer/register
  register(customer: any): Observable<any> {
    return this.http.post(`${BASE_URL}/customer/register`, customer);
  }

  // ✅ Login with customerId and PIN
  login(id: number, pin: string): Observable<any> {
    return this.http.post(`${BASE_URL}/customer/login`, {
      customerId: id,
      pin: pin
    });
  }

  // ✅ Deposit money
  deposit(customerId: number, amount: number): Observable<any> {
    return this.http.post(`${BASE_URL}/transaction/deposit`, {
      customerId,
      amount
    });
  }

  // ✅ Withdraw money
  withdraw(customerId: number, amount: number): Observable<any> {
    return this.http.post(`${BASE_URL}/transaction/withdraw`, {
      customerId,
      amount
    });
  }

  // ✅ Get current balance
  getBalance(customerId: number): Observable<any> {
    return this.http.get(`${BASE_URL}/transaction/balance?customerId=${customerId}`);
  }

  // ✅ NEW: Get all customer IDs and details for "Forgot ID" feature
  getAllCustomerIds(): Observable<any> {
    return this.http.get(`${BASE_URL}/customer/forgot-ids`);
  }
}

﻿using BankingBackend.Repositories;
using BankingBackend.Services;

var builder = WebApplication.CreateBuilder(args);

// 🔧 Register Services & Repositories
builder.Services.AddSingleton<DatabaseService>(); // Use singleton to persist MongoDB connection
builder.Services.AddScoped<CustomerRepository>();
builder.Services.AddScoped<TransactionRepository>();

// 🔧 Add Controllers, Swagger, and CORS
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// 🔧 CORS Policy for Angular
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularClient", policy =>
    {
        policy.WithOrigins("http://localhost:4200") // Angular dev server
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

// ✅ Middleware Pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 🔐 CORS should be before authorization & routing
app.UseCors("AllowAngularClient");

app.UseAuthorization();

app.MapControllers();

app.Run();

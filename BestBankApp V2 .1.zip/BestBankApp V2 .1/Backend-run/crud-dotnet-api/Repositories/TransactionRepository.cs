﻿using BankingBackend.Models;
using BankingBackend.Services;
using Dapper;

namespace BankingBackend.Repositories
{
    public class TransactionRepository
    {
        private readonly DatabaseService _db;

        public TransactionRepository(DatabaseService db)
        {
            _db = db;
        }

        public async Task<bool> WithdrawAsync(int customerId, decimal amount)
        {
            using var conn = _db.CreateConnection();
            var customer = await conn.QueryFirstOrDefaultAsync<Customer>(
                "SELECT * FROM Customers WHERE Id = @Id", new { Id = customerId });

            if (customer == null || customer.Balance < amount)
                return false;

            var newBalance = customer.Balance - amount;

            var sql = "UPDATE Customers SET Balance = @Balance WHERE Id = @Id";
            await conn.ExecuteAsync(sql, new { Balance = newBalance, Id = customerId });

            return true;
        }

        public async Task<bool> DepositAsync(int customerId, decimal amount)
        {
            using var conn = _db.CreateConnection();
            var customer = await conn.QueryFirstOrDefaultAsync<Customer>(
                "SELECT * FROM Customers WHERE Id = @Id", new { Id = customerId });

            if (customer == null)
                return false;

            var newBalance = customer.Balance + amount;

            var sql = "UPDATE Customers SET Balance = @Balance WHERE Id = @Id";
            await conn.ExecuteAsync(sql, new { Balance = newBalance, Id = customerId });

            return true;
        }

        public async Task<decimal?> GetBalanceAsync(int customerId)
        {
            using var conn = _db.CreateConnection();
            var customer = await conn.QueryFirstOrDefaultAsync<Customer>(
                "SELECT * FROM Customers WHERE Id = @Id", new { Id = customerId });

            return customer?.Balance;
        }
    }
}

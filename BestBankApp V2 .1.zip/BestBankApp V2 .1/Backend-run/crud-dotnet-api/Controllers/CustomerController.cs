﻿using Microsoft.AspNetCore.Mvc;
using BankingBackend.Models;
using BankingBackend.Repositories;

namespace BankingBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly CustomerRepository _repository;

        public CustomerController(CustomerRepository repository)
        {
            _repository = repository;
        }

        // ✅ POST: api/customer/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var customer = await _repository.LoginAsync(request.CustomerId, request.Pin);
            if (customer == null)
                return Unauthorized("Invalid credentials");

            return Ok(customer);
        }

        // ✅ POST: api/customer/register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Customer customer)
        {
            if (customer == null || string.IsNullOrWhiteSpace(customer.Name))
                return BadRequest("Invalid customer data.");

            await _repository.AddAsync(customer);
            return Ok(new { message = "Registration successful" });
        }

        // ✅ GET: api/customer
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var customers = await _repository.GetAllAsync();
            var result = customers.Select(c => new
            {
                c.Id,
                c.Name,
                c.Email,
                c.Phone,
                c.Balance
            });

            return Ok(result);
        }

        // ✅ GET: api/customer/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var customer = await _repository.GetByIdAsync(id);
            if (customer == null)
                return NotFound();

            return Ok(new
            {
                customer.Id,
                customer.Name,
                customer.Email,
                customer.Phone,
                customer.Balance
            });
        }

        // ✅ GET: api/customer/forgot-ids
        [HttpGet("forgot-ids")]
        public async Task<IActionResult> GetAllCustomerIds()
        {
            var customers = await _repository.GetAllAsync();
            var result = customers.Select(c => new
            {
                c.Id,
                c.Name,
                c.Email,
                c.Phone
            });

            return Ok(result);
        }
    }
}

﻿using Grpc.Core;
using BankingBackend.Repositories;
using GrpcModels = BankingBackend.Grpc;

namespace BankingBackend.Services.Grpc
{
    public class TransactionGrpcService : GrpcModels.TransactionService.TransactionServiceBase
    {
        private readonly TransactionRepository _repo;

        public TransactionGrpcService(TransactionRepository repo)
        {
            _repo = repo;
        }

        public override async Task<GrpcModels.MessageResponse> Deposit(GrpcModels.TransactionRequest request, ServerCallContext context)
        {
            var success = await _repo.DepositAsync(request.CustomerId, (decimal)request.Amount);
            if (!success)
                throw new RpcException(new Status(StatusCode.NotFound, "Customer not found"));

            return new GrpcModels.MessageResponse { Message = "Deposited successfully" };
        }

        public override async Task<GrpcModels.MessageResponse> Withdraw(GrpcModels.TransactionRequest request, ServerCallContext context)
        {
            var success = await _repo.WithdrawAsync(request.CustomerId, (decimal)request.Amount);
            if (!success)
                throw new RpcException(new Status(StatusCode.InvalidArgument, "Insufficient balance or not found"));

            return new GrpcModels.MessageResponse { Message = "Withdrawn successfully" };
        }

        public override async Task<GrpcModels.BalanceResponse> GetBalance(GrpcModels.CustomerIdRequest request, ServerCallContext context)
        {
            var balance = await _repo.GetBalanceAsync(request.CustomerId);
            if (balance == null)
                throw new RpcException(new Status(StatusCode.NotFound, "Customer not found"));

            return new GrpcModels.BalanceResponse
            {
                CustomerId = request.CustomerId,
                Balance = (double)balance
            };
        }
    }
}

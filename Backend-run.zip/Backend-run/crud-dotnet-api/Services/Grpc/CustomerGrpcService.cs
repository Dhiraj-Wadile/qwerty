﻿using Grpc.Core;
using GrpcModels = BankingBackend.Grpc;
using Models = BankingBackend.Models;
using BankingBackend.Repositories;

namespace BankingBackend.Services.Grpc
{
    public class CustomerGrpcService : GrpcModels.CustomerService.CustomerServiceBase
    {
        private readonly CustomerRepository _repo;

        public CustomerGrpcService(CustomerRepository repo)
        {
            _repo = repo;
        }

        public override async Task<GrpcModels.CustomerResponse> Login(GrpcModels.LoginRequest request, ServerCallContext context)
        {
            var customer = await _repo.LoginAsync(request.CustomerId, request.Pin);
            if (customer == null)
                throw new RpcException(new Status(StatusCode.Unauthenticated, "Invalid credentials"));

            return MapCustomer(customer);
        }

        public override async Task<GrpcModels.MessageResponse> Register(GrpcModels.CustomerRequest request, ServerCallContext context)
        {
            var customer = new Models.Customer
            {
                Name = request.Name,
                Email = request.Email,
                Phone = request.Phone,
                Pin = request.Pin,
                Balance = (decimal)request.Balance
            };

            await _repo.AddAsync(customer);

            return new GrpcModels.MessageResponse { Message = "Registration successful" };
        }

        public override async Task<GrpcModels.CustomerResponse> GetCustomerById(GrpcModels.CustomerIdRequest request, ServerCallContext context)
        {
            var customer = await _repo.GetByIdAsync(request.CustomerId);
            if (customer == null)
                throw new RpcException(new Status(StatusCode.NotFound, "Customer not found"));

            return MapCustomer(customer);
        }

        public override async Task<GrpcModels.CustomerList> GetAllCustomers(GrpcModels.Empty request, ServerCallContext context)
        {
            var customers = await _repo.GetAllAsync();
            var list = new GrpcModels.CustomerList();
            list.Customers.AddRange(customers.Select(c => MapCustomer(c)));
            return list;
        }

        private GrpcModels.CustomerResponse MapCustomer(Models.Customer c)
        {
            return new GrpcModels.CustomerResponse
            {
                Id = c.Id,
                Name = c.Name,
                Email = c.Email,
                Phone = c.Phone,
                Balance = (double)c.Balance
            };
        }
    }
}

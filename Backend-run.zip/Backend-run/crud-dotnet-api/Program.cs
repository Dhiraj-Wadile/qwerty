﻿using BankingBackend.Repositories;
using BankingBackend.Services;
using BankingBackend.Services.Grpc;

var builder = WebApplication.CreateBuilder(args);

// ✅ Kestrel gRPC port binding (Manual way for .NET 8)
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(5243); // REST API (Swagger)
    options.ListenAnyIP(5001, listenOptions =>
    {
        listenOptions.Protocols = Microsoft.AspNetCore.Server.Kestrel.Core.HttpProtocols.Http2;
    }); // gRPC
});

// 🔧 Register Services & Repositories
builder.Services.AddSingleton<DatabaseService>();
builder.Services.AddScoped<CustomerRepository>();
builder.Services.AddScoped<TransactionRepository>();

builder.Services.AddControllers();
builder.Services.AddGrpc();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// 🔧 CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularClient", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowAngularClient");
app.UseAuthorization();

app.MapControllers();
app.MapGrpcService<CustomerGrpcService>();
app.MapGrpcService<TransactionGrpcService>();

app.Run();

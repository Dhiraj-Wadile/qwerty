﻿using BankingBackend.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace BankingBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly TransactionRepository _repo;

        public TransactionController(TransactionRepository repo)
        {
            _repo = repo;
        }

        public class TransactionRequest
        {
            public int CustomerId { get; set; }
            public decimal Amount { get; set; }
        }

        [HttpPost("deposit")]
        public async Task<IActionResult> Deposit([FromBody] TransactionRequest request)
        {
            if (request.Amount <= 0)
                return BadRequest("Amount must be greater than zero.");

            var result = await _repo.DepositAsync(request.CustomerId, request.Amount);
            if (!result)
                return BadRequest("Customer not found or deposit failed.");

            return Ok(new
            {
                Message = "Deposited successfully",
                CustomerId = request.CustomerId,
                Amount = request.Amount
            });
        }

        [HttpPost("withdraw")]
        public async Task<IActionResult> Withdraw([FromBody] TransactionRequest request)
        {
            if (request.Amount <= 0)
                return BadRequest("Amount must be greater than zero.");

            var success = await _repo.WithdrawAsync(request.CustomerId, request.Amount);
            if (!success)
                return BadRequest("Insufficient balance or customer not found.");

            return Ok(new
            {
                Message = "Withdrawn successfully",
                CustomerId = request.CustomerId,
                Amount = request.Amount
            });
        }

        [HttpGet("balance")]
        public async Task<IActionResult> GetBalance([FromQuery] int customerId)
        {
            var balance = await _repo.GetBalanceAsync(customerId);
            if (balance == null)
                return NotFound("Customer not found.");

            return Ok(new { CustomerId = customerId, Balance = balance });
        }
    }
}

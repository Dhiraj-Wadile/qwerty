﻿using BankServer.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// 👇 Make server listen on HTTP port 5000 (localhost:5000)
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenLocalhost(5000); // HTTP
});

builder.Services.AddGrpc();

var app = builder.Build();

app.MapGrpcService<BankServiceImpl>();
app.MapGet("/", () => "Bank gRPC Server running...");

app.Run();

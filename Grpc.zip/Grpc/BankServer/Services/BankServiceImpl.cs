﻿using Bank;
using Grpc.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BankServer.Services
{
    public class BankServiceImpl : BankService.BankServiceBase
    {
        private static readonly Dictionary<int, double> Accounts = new();
        private static int _nextId = 1;

        public override Task<CreateAccountResponse> CreateAccount(CreateAccountRequest request, ServerCallContext context)
        {
            int id = _nextId++;
            Accounts[id] = 1000; // default balance
            return Task.FromResult(new CreateAccountResponse
            {
                AccountId = id,
                Message = $"Account created for {request.Name}"
            });
        }

        public override Task<CheckBalanceResponse> CheckBalance(CheckBalanceRequest request, ServerCallContext context)
        {
            Accounts.TryGetValue(request.AccountId, out var balance);
            return Task.FromResult(new CheckBalanceResponse { Balance = balance });
        }

        public override Task<TransferFundsResponse> TransferFunds(TransferFundsRequest request, ServerCallContext context)
        {
            if (!Accounts.ContainsKey(request.FromAccountId) || !Accounts.ContainsKey(request.ToAccountId))
            {
                return Task.FromResult(new TransferFundsResponse { Status = "Invalid account ID" });
            }

            if (Accounts[request.FromAccountId] < request.Amount)
            {
                return Task.FromResult(new TransferFundsResponse { Status = "Insufficient balance" });
            }

            Accounts[request.FromAccountId] -= request.Amount;
            Accounts[request.ToAccountId] += request.Amount;

            return Task.FromResult(new TransferFundsResponse { Status = "Transfer Successful" });
        }
    }
}

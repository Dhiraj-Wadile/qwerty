﻿using System;
using System.Threading.Tasks;
using Grpc.Net.Client;
using Bank;

class Program
{
    static async Task Main(string[] args)
    {
        try
        {
            using var channel = GrpcChannel.ForAddress("http://localhost:5000");
            var client = new BankService.BankServiceClient(channel);

            var createRes = await client.CreateAccountAsync(new CreateAccountRequest { Name = "Ankit" });
            Console.WriteLine($"Created Account ID for Ankit: {createRes.AccountId}");

            var balanceRes = await client.CheckBalanceAsync(new CheckBalanceRequest { AccountId = createRes.AccountId });
            Console.WriteLine($"Ankit's Balance: {balanceRes.Balance}");

            var create2 = await client.CreateAccountAsync(new CreateAccountRequest { Name = "Neha" });
            Console.WriteLine($"Created Account ID for Neha: {create2.AccountId}");

            var transfer = await client.TransferFundsAsync(new TransferFundsRequest
            {
                FromAccountId = createRes.AccountId,
                ToAccountId = create2.AccountId,
                Amount = 300
            });
            Console.WriteLine($"Transfer Status: {transfer.Status}");

            var updatedAnkit = await client.CheckBalanceAsync(new CheckBalanceRequest { AccountId = createRes.AccountId });
            Console.WriteLine($"Updated Ankit Balance: {updatedAnkit.Balance}");

            var updatedNeha = await client.CheckBalanceAsync(new CheckBalanceRequest { AccountId = create2.AccountId });
            Console.WriteLine($"Updated Neha Balance: {updatedNeha.Balance}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error occurred:");
            Console.WriteLine(ex.Message);
        }
    }
}

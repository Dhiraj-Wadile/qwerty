﻿using BankingApp.gRPC.Services; // ✅ Correct namespace
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// ✅ Register gRPC Service
builder.Services.AddGrpc();

var app = builder.Build();

app.UseRouting();

// ✅ Ensure correct service registration
app.UseEndpoints(endpoints =>
{
    endpoints.MapGrpcService<BankingService>(); // ✅ Ensure `BankingService` is mapped correctly
});

app.MapGet("/", () => "🚀 gRPC Banking Service is Running!");

app.Run();

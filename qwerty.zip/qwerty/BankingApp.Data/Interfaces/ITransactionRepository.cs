﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BankingApp.Models;

namespace BankingApp.Data.Interfaces
{
    public interface ITransactionRepository
    {
        Task<int> AddTransactionAsync(Transaction transaction);
        Task<IEnumerable<Transaction>> GetTransactionsByCustomerIdAsync(int customerId);
        Task<decimal> GetCustomerBalanceAsync(int customerId);
    }
}

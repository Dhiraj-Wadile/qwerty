﻿using Dapper;
using BankingApp.Data.Interfaces;
using BankingApp.Models;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace BankingApp.Data.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly IDbConnection _dbConnection;

        public CustomerRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection ?? throw new ArgumentNullException(nameof(dbConnection)); // ✅ Ensuring valid connection
        }

        public async Task<int> AddCustomerAsync(Customer customer)
        {
            const string sql = @"
                INSERT INTO Customers (Name, Email, Phone, PinHash) 
                VALUES (@Name, @Email, @Phone, @PinHash);
                SELECT CAST(SCOPE_IDENTITY() as int);";

            return await _dbConnection.ExecuteScalarAsync<int>(sql, customer);
        }

        public async Task<Customer> GetCustomerByIdAsync(int id)
        {
            const string sql = "SELECT * FROM Customers WHERE Id = @Id;";
            return await _dbConnection.QuerySingleOrDefaultAsync<Customer>(sql, new { Id = id });
        }

        public async Task<IEnumerable<Customer>> GetAllCustomersAsync()
        {
            const string sql = "SELECT * FROM Customers;";
            return await _dbConnection.QueryAsync<Customer>(sql);
        }

        public async Task<bool> VerifyCustomerPinAsync(int id, string pin)
        {
            const string sql = "SELECT PinHash FROM Customers WHERE Id = @Id;";
            var storedPin = await _dbConnection.QuerySingleOrDefaultAsync<string>(sql, new { Id = id });
            return storedPin == pin;
        }
    }
}

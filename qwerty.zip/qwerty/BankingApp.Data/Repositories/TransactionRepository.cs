﻿using Dapper;
using BankingApp.Data.Interfaces;
using BankingApp.Models;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace BankingApp.Data.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly IDbConnection _dbConnection;

        public TransactionRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<int> AddTransactionAsync(Transaction transaction)
        {
            string sql = "INSERT INTO Transactions (CustomerId, Amount, Type, Date) VALUES (@CustomerId, @Amount, @Type, @Date); SELECT CAST(SCOPE_IDENTITY() as int)";
            return await _dbConnection.ExecuteScalarAsync<int>(sql, transaction);
        }

        public async Task<IEnumerable<Transaction>> GetTransactionsByCustomerIdAsync(int customerId)
        {
            string sql = "SELECT * FROM Transactions WHERE CustomerId = @CustomerId";
            return await _dbConnection.QueryAsync<Transaction>(sql, new { CustomerId = customerId });
        }

        public async Task<decimal> GetCustomerBalanceAsync(int customerId)
        {
            string sql = "SELECT SUM(CASE WHEN Type = 'Deposit' THEN Amount ELSE -Amount END) FROM Transactions WHERE CustomerId = @CustomerId";
            return await _dbConnection.ExecuteScalarAsync<decimal>(sql, new { CustomerId = customerId });
        }
    }
}

﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankingApp.Core.Interfaces;
using BankingApp.Data.Interfaces;
using BankingApp.Models;

namespace BankingApp.Core.Services
{
    public class TransactionService : ITransactionService
    {
        private readonly ITransactionRepository _transactionRepository;

        public TransactionService(ITransactionRepository transactionRepository)
        {
            _transactionRepository = transactionRepository;
        }

        public async Task<int> AddTransactionAsync(Transaction transaction)
        {
            return await _transactionRepository.AddTransactionAsync(transaction);
        }

        public async Task<IEnumerable<Transaction>> GetTransactionsByCustomerIdAsync(int customerId)
        {
            return await _transactionRepository.GetTransactionsByCustomerIdAsync(customerId);
        }

        public async Task<decimal> GetCustomerBalanceAsync(int customerId)
        {
            var transactions = await _transactionRepository.GetTransactionsByCustomerIdAsync(customerId);
            return transactions.Sum(t => t.Type == "Deposit" ? t.Amount : -t.Amount);
        }
    }
}

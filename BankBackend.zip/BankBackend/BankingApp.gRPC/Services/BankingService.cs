﻿using BankingApp.gRPC.Protos;  // ✅ Ensure the correct namespace
using Grpc.Core;
using System.Threading.Tasks;

namespace BankingApp.gRPC.Services
{
    public class BankingService : BankingApp.gRPC.Protos.BankingService.BankingServiceBase
    {
        public override Task<BalanceResponse> GetBalance(BalanceRequest request, ServerCallContext context)
        {
            return Task.FromResult(new BalanceResponse
            {
                Balance = 1000.00 // Example static balance
            });
        }
    }
}

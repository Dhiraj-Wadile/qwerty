﻿using Microsoft.AspNetCore.Mvc;
using BankingApp.Core.Interfaces;
using BankingApp.Models;
using System.Threading.Tasks;

namespace BankingApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionService _transactionService;

        public TransactionController(ITransactionService transactionService)
        {
            _transactionService = transactionService;
        }

        [HttpPost("deposit")]
        public async Task<IActionResult> Deposit(Transaction transaction)
        {
            int id = await _transactionService.AddTransactionAsync(transaction);
            return Ok(new { TransactionId = id });
        }

        [HttpGet("balance/{customerId}")]
        public async Task<IActionResult> GetBalance(int customerId)
        {
            var balance = await _transactionService.GetCustomerBalanceAsync(customerId);
            return Ok(new { Balance = balance });
        }
    }
}

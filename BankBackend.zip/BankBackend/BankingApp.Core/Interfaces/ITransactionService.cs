﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BankingApp.Models;

namespace BankingApp.Core.Interfaces
{
    public interface ITransactionService
    {
        Task<int> AddTransactionAsync(Transaction transaction);
        Task<IEnumerable<Transaction>> GetTransactionsByCustomerIdAsync(int customerId);
        Task<decimal> GetCustomerBalanceAsync(int customerId);
    }
}
